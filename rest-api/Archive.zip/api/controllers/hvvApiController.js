'use strict';
var IOTA = require('iota.lib.js')
var seed = 'BVENQWWDWLKBFRZJJYADNPVE9NNSMUYDAQQZLRLZSEFSQAHNFVNGWTTJPKGQJHFYMAVJRFQCGUPAMBLHZ';
//var seed = 'YFVQGQQXUSP9PMJYGNKHNETXYTVDDAAUZU9DMUOUHMVXGIZOQWQJJS9M9IDYSQQLVBFTVCY9MQWBSVOLC';
var iota = new IOTA({
    'provider': 'http://52.58.212.188:14700'
});

exports.getAddress = function(req, res) {
  // Deterministically generates a new address for the specified seed with a checksum
  iota.api.getNewAddress( seed, { 'checksum': true }, function( e, add ) {
      if (!e) {
          console.log("Generated new address: ", add)
          res.send(add);
      } else {
          console.log("Something went wrong: ", e);
      }
  })
}

exports.getData = function(req, cb) {
  //console.log("inside interval..");
  // req is a array with IOTA adresses
  var arr = [];
  var output = [];
  console.log(req.body);
  console.log(typeof req.body);
  iota.api.findTransactions(req.body, function(e, res) {
    if (e) throw e;
    console.log("Result ", res);
    iota.api.getTransactionsObjects(res, function(e, res) {
        if (e) throw e;
        //console.log(res);
        for (var i = 0; i < res.length-1; i++) {
          if (arr.indexOf(res[i].hash) > -1) {
              }
          else {
            var result = res[i].signatureMessageFragment;
            //console.log("data before substring file: ", result);
            result = result.substring(0, result.indexOf('99'));
            //console.log("data after substring file: ", result);
            result = iota.utils.fromTrytes(result);
            //console.log("dats file: ", result);
            var data = JSON.parse(result);
            var json = {
            "sensorboxID": res[i].address, // Thats the IOTA key
            "sensors": {
              "name": data.sensors.name,
              "value": data.sensors.value,
              "timestamp": res[i].timestamp
              }
            }
            console.log(JSON.stringify(json));
            arr.push(res[i].hash);
            output.push(json);
      }
    }
    cb.send(output);
    })
})
}

exports.postData = function(req, res) {

  var messageToSend = {
      "sensorboxID": req.sensorboxID, // Thats the IOTA key
      "sensors": {
        "name": req.sensors.name,
        "value": req.sensors.value
      }
  };
  // Stringify to JSON
  var messageStringified = JSON.stringify(messageToSend);
  console.log(messageStringified);
  // Convert the string to trytes
  messageTrytes = iota.utils.toTrytes(messageStringified);
  console.log('Message to send: ', messageTrytes); //ODGABDPCADTCGADBGANBCDADXCBDXCZCGAQAGAADTCGDGDPCVCTCGADBGAWBMDEAUCXCFDGDHDEAADTCGDGDPCVCTCEAGDTCBDHDEAKDXCHDWCEASBYBCCKBSAGAQD
  console.log('In Bytes: ', iota.utils.fromTrytes(messageTrytes));
  // here we define the transfers object, each entry is an individual transaction
  var transfer = [{
      'address': address,
      'value': 0,
      'message': messageTrytes
  }]
  // We send the transfer from this seed, with depth 4 and minWeightMagnitude 9 = because tesnet // 15 = main net
  iota.api.sendTransfer(seed, 4, 9, transfer, function(e, bundle) {
      if (e) cb("Error: " + e);
      cb("Successfully sent your transfer: " + bundle);
  })


}
